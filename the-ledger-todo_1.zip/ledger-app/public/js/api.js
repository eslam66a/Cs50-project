// public/js/api.js
// Thin wrapper around fetch() for talking to the Express + SQLite backend.
// Every function returns a Promise that resolves with parsed JSON, or
// throws an Error with a readable message on failure.

const Api = (() => {
  async function request(url, options = {}) {
    const res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      ...options
    });
    if (!res.ok) {
      let message = `Request failed (${res.status})`;
      try {
        const body = await res.json();
        if (body.error) message = body.error;
      } catch (_) { /* ignore parse errors on error responses */ }
      throw new Error(message);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  return {
    getTasks: () => request('/api/tasks'),

    createTask: (text) => request('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({ text })
    }),

    updateTask: (id, patch) => request(`/api/tasks/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch)
    }),

    deleteTask: (id) => request(`/api/tasks/${id}`, { method: 'DELETE' }),

    restoreTask: (task) => request('/api/tasks/restore', {
      method: 'POST',
      body: JSON.stringify({ task })
    }),

    reorderTasks: (orderedIds) => request('/api/tasks/reorder', {
      method: 'POST',
      body: JSON.stringify({ orderedIds })
    }),

    clearCompleted: () => request('/api/tasks/clear-completed', { method: 'POST' }),

    restoreMany: (tasks) => request('/api/tasks/restore-many', {
      method: 'POST',
      body: JSON.stringify({ tasks })
    }),

    importTasks: (tasks) => request('/api/import', {
      method: 'POST',
      body: JSON.stringify({ tasks })
    }),

    exportUrl: '/api/export'
  };
})();
