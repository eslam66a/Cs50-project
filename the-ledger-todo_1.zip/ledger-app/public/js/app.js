// public/js/app.js
// UI state and rendering. Task data is fetched from and persisted to the
// Express + SQLite backend through the Api module (see api.js). A local
// `tasks` array is kept as a render cache, always a mirror of server state.

let tasks = [];
let currentFilter = 'all';
let currentTagFilter = '';
let currentSort = 'manual';
let searchQuery = '';
let expandedIds = new Set();
let dragSourceId = null;

const PRIORITY_CYCLE = ['none', 'low', 'medium', 'high'];
const PRIORITY_LABEL = { none: 'No priority', low: 'Low priority', medium: 'Medium priority', high: 'High priority' };
const PRIORITY_RANK = { high: 0, medium: 1, low: 2, none: 3 };

/* ---------------------------------------------------------
   DATE STAMP + THEME (theme preference persists via localStorage —
   this is a real page served by our own server, not a sandboxed
   preview, so normal browser storage is the right tool here)
--------------------------------------------------------- */
(function setDateStamp(){
  const d = new Date();
  const opts = { weekday: 'long', month: 'short', day: 'numeric' };
  document.getElementById('date-stamp').textContent = d.toLocaleDateString(undefined, opts);
})();

(function initTheme(){
  const saved = localStorage.getItem('ledger-theme');
  if (saved) document.body.setAttribute('data-theme', saved);
})();

document.getElementById('theme-toggle').addEventListener('click', () => {
  const isDark = document.body.getAttribute('data-theme') === 'dark';
  const next = isDark ? 'light' : 'dark';
  document.body.setAttribute('data-theme', next);
  localStorage.setItem('ledger-theme', next);
});

/* ---------------------------------------------------------
   DUE DATE HELPERS
--------------------------------------------------------- */
function dueBadgeInfo(dateStr){
  if(!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const due = new Date(dateStr + 'T00:00:00');
  const diffDays = Math.round((due - today) / 86400000);
  if(diffDays < 0) return { text: 'Overdue', cls: 'overdue' };
  if(diffDays === 0) return { text: 'Today', cls: 'today' };
  if(diffDays === 1) return { text: 'Tomorrow', cls: 'soon' };
  if(diffDays <= 6) return { text: due.toLocaleDateString(undefined, { weekday: 'short' }), cls: 'soon' };
  return { text: due.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), cls: 'normal' };
}

/* ---------------------------------------------------------
   DERIVED LISTS
--------------------------------------------------------- */
function getSortedTasks(){
  const arr = tasks.slice();
  if(currentSort === 'priority'){
    arr.sort((a,b) => PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]);
  } else if(currentSort === 'due'){
    arr.sort((a,b) => {
      if(!a.due && !b.due) return 0;
      if(!a.due) return 1;
      if(!b.due) return -1;
      return a.due.localeCompare(b.due);
    });
  } else if(currentSort === 'alpha'){
    arr.sort((a,b) => a.text.localeCompare(b.text));
  }
  return arr;
}

function getVisibleTasks(){
  return getSortedTasks().filter(t => {
    if(currentFilter === 'active' && t.done) return false;
    if(currentFilter === 'done' && !t.done) return false;
    if(currentTagFilter && t.tag.toLowerCase() !== currentTagFilter.toLowerCase()) return false;
    if(searchQuery){
      const q = searchQuery.toLowerCase();
      const hay = (t.text + ' ' + t.tag + ' ' + t.notes).toLowerCase();
      if(!hay.includes(q)) return false;
    }
    return true;
  });
}

function refreshTagFilterOptions(){
  const select = document.getElementById('tag-filter');
  const current = select.value;
  const tags = Array.from(new Set(tasks.map(t => t.tag).filter(Boolean))).sort((a,b) => a.localeCompare(b));
  select.innerHTML = '<option value="">All tags</option>' + tags.map(t => `<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('');
  if(tags.includes(current)) select.value = current;
  else currentTagFilter = '';
}

function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* ---------------------------------------------------------
   CORE RENDER
--------------------------------------------------------- */
function render(){
  refreshTagFilterOptions();
  const ledgerEl = document.getElementById('ledger');
  ledgerEl.innerHTML = '';

  const visible = getVisibleTasks();
  const manualMode = currentSort === 'manual';

  if(tasks.length === 0){
    ledgerEl.innerHTML = `<div class="empty-state">Nothing on the ledger yet — add your first line above.</div>`;
  } else if(visible.length === 0){
    ledgerEl.innerHTML = `<div class="empty-state">No tasks match the current search or filters.</div>`;
  } else {
    visible.forEach((task, i) => {
      ledgerEl.appendChild(buildRow(task, i, manualMode));
    });
  }

  updateFooterAndProgress();
}

function buildRow(task, displayIndex, manualMode){
  const row = document.createElement('div');
  row.className = 'task-row' + (task.done ? ' done' : '');
  row.dataset.id = task.id;
  row.draggable = manualMode;

  if(manualMode){
    row.addEventListener('dragstart', (e) => { dragSourceId = task.id; e.dataTransfer.effectAllowed = 'move'; });
    row.addEventListener('dragover', (e) => { e.preventDefault(); row.classList.add('drag-over'); });
    row.addEventListener('dragleave', () => row.classList.remove('drag-over'));
    row.addEventListener('drop', (e) => {
      e.preventDefault();
      row.classList.remove('drag-over');
      reorderTasks(dragSourceId, task.id);
    });
  }

  const main = document.createElement('div');
  main.className = 'task-main';

  const handle = document.createElement('span');
  handle.className = 'drag-handle' + (manualMode ? '' : ' disabled');
  handle.textContent = '⋮⋮';
  handle.title = manualMode ? 'Drag to reorder' : 'Switch to Manual order to drag';

  const lineNo = document.createElement('div');
  lineNo.className = 'line-no';
  lineNo.textContent = String(displayIndex + 1).padStart(2, '0');

  const check = document.createElement('button');
  check.className = 'check';
  check.innerHTML = `<svg viewBox="0 0 14 14"><path d="M2 7.5L5.5 11L12 3"/></svg>`;
  check.addEventListener('click', () => toggleDone(task.id));

  const body = document.createElement('div');
  body.className = 'task-body';

  const text = document.createElement('div');
  text.className = 'task-text';
  text.textContent = task.text;
  body.appendChild(text);

  const meta = document.createElement('div');
  meta.className = 'task-meta';
  if(task.due){
    const info = dueBadgeInfo(task.due);
    const badge = document.createElement('span');
    badge.className = 'due-badge ' + info.cls;
    badge.textContent = info.text;
    meta.appendChild(badge);
  }
  if(task.tag){
    const chip = document.createElement('span');
    chip.className = 'tag-chip';
    chip.textContent = '#' + task.tag;
    meta.appendChild(chip);
  }
  if(meta.children.length) body.appendChild(meta);

  if(task.notes){
    const preview = document.createElement('div');
    preview.className = 'note-preview';
    preview.textContent = task.notes;
    body.appendChild(preview);
  }

  const flag = document.createElement('button');
  flag.className = 'flag-dot' + (task.priority !== 'none' ? ' ' + task.priority : '');
  flag.title = PRIORITY_LABEL[task.priority] + ' — click to cycle';
  flag.addEventListener('click', () => cyclePriority(task.id));

  const expandBtn = document.createElement('button');
  expandBtn.className = 'expand-btn' + (expandedIds.has(task.id) ? ' open' : '');
  expandBtn.innerHTML = '⌄';
  expandBtn.title = 'Edit details';
  expandBtn.addEventListener('click', () => toggleExpand(task.id));

  const remove = document.createElement('button');
  remove.className = 'remove-btn';
  remove.textContent = '×';
  remove.title = 'Remove';
  remove.addEventListener('click', () => removeTask(task.id));

  main.appendChild(handle);
  main.appendChild(lineNo);
  main.appendChild(check);
  main.appendChild(body);
  main.appendChild(flag);
  main.appendChild(expandBtn);
  main.appendChild(remove);
  row.appendChild(main);

  row.appendChild(buildEditPanel(task));

  return row;
}

function buildEditPanel(task){
  const panel = document.createElement('div');
  panel.className = 'edit-panel' + (expandedIds.has(task.id) ? ' open' : '');

  const textField = document.createElement('div');
  textField.className = 'edit-field';
  textField.innerHTML = `<label>Task</label>`;
  const textInput = document.createElement('input');
  textInput.type = 'text'; textInput.value = task.text; textInput.maxLength = 140;
  textField.appendChild(textInput);

  const row1 = document.createElement('div');
  row1.className = 'edit-row';

  const dueField = document.createElement('div');
  dueField.className = 'edit-field';
  dueField.innerHTML = `<label>Due date</label>`;
  const dueInput = document.createElement('input');
  dueInput.type = 'date'; dueInput.value = task.due || '';
  dueField.appendChild(dueInput);

  const tagField = document.createElement('div');
  tagField.className = 'edit-field';
  tagField.innerHTML = `<label>Tag</label>`;
  const tagInput = document.createElement('input');
  tagInput.type = 'text'; tagInput.placeholder = 'e.g. work'; tagInput.maxLength = 24; tagInput.value = task.tag || '';
  tagField.appendChild(tagInput);

  row1.appendChild(dueField);
  row1.appendChild(tagField);

  const priField = document.createElement('div');
  priField.className = 'edit-field';
  priField.innerHTML = `<label>Priority</label>`;
  const priSelect = document.createElement('div');
  priSelect.className = 'priority-select';
  ['none','low','medium','high'].forEach(p => {
    const opt = document.createElement('button');
    opt.type = 'button';
    opt.className = 'priority-opt' + (task.priority === p ? ' active-' + p : '');
    opt.textContent = p === 'none' ? '—' : p[0].toUpperCase() + p.slice(1);
    opt.dataset.value = p;
    opt.addEventListener('click', () => {
      priSelect.querySelectorAll('.priority-opt').forEach(o => o.className = 'priority-opt');
      opt.className = 'priority-opt active-' + p;
      priSelect.dataset.selected = p;
    });
    priSelect.appendChild(opt);
  });
  priSelect.dataset.selected = task.priority;
  priField.appendChild(priSelect);

  const notesField = document.createElement('div');
  notesField.className = 'edit-field';
  notesField.innerHTML = `<label>Notes</label>`;
  const notesArea = document.createElement('textarea');
  notesArea.placeholder = 'Optional details…';
  notesArea.value = task.notes || '';
  notesField.appendChild(notesArea);

  const actions = document.createElement('div');
  actions.className = 'edit-actions';
  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'btn-small btn-cancel'; cancelBtn.textContent = 'Cancel';
  cancelBtn.addEventListener('click', () => { collapseExpand(task.id); });
  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn-small btn-save'; saveBtn.textContent = 'Save';
  saveBtn.addEventListener('click', () => {
    saveTaskEdits(task.id, {
      text: textInput.value.trim() || task.text,
      due: dueInput.value || '',
      tag: tagInput.value.trim(),
      priority: priSelect.dataset.selected,
      notes: notesArea.value.trim()
    });
  });
  actions.appendChild(cancelBtn);
  actions.appendChild(saveBtn);

  panel.appendChild(textField);
  panel.appendChild(row1);
  panel.appendChild(priField);
  panel.appendChild(notesField);
  panel.appendChild(actions);

  textInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') saveBtn.click(); if(e.key === 'Escape') cancelBtn.click(); });
  tagInput.addEventListener('keydown', (e) => { if(e.key === 'Enter') saveBtn.click(); if(e.key === 'Escape') cancelBtn.click(); });

  return panel;
}

function updateFooterAndProgress(){
  const total = tasks.length;
  const done = tasks.filter(t => t.done).length;
  const remaining = total - done;
  const label = remaining === 1 ? '1 item left' : `${remaining} items left`;
  document.getElementById('count-text').textContent = total ? label : '0 items';

  const pct = total ? Math.round((done/total) * 100) : 0;
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-text').textContent = `${done} of ${total} complete`;
  document.getElementById('progress-pct').textContent = pct + '%';
}

/* ---------------------------------------------------------
   ACTIONS — each mutates the local cache optimistically, then
   confirms with the server. On failure the list is re-synced.
--------------------------------------------------------- */
async function resyncFromServer(errorMessage){
  try {
    tasks = await Api.getTasks();
  } catch (_) { /* if this also fails, keep the last known state */ }
  render();
  if (errorMessage) showToast(errorMessage, null);
}

async function addTask(){
  const input = document.getElementById('task-input');
  const value = input.value.trim();
  if(!value) return;
  input.value = '';
  input.disabled = true;
  try {
    const created = await Api.createTask(value);
    tasks.push(created);
    render();
  } catch (err) {
    input.value = value;
    showToast(err.message, null);
  } finally {
    input.disabled = false;
    input.focus();
  }
}

async function toggleDone(id){
  const t = tasks.find(t => t.id === id);
  if(!t) return;
  t.done = !t.done;
  render();
  try {
    await Api.updateTask(id, { done: t.done });
  } catch (err) {
    await resyncFromServer('Could not update that task — ' + err.message);
  }
}

async function cyclePriority(id){
  const t = tasks.find(t => t.id === id);
  if(!t) return;
  const idx = PRIORITY_CYCLE.indexOf(t.priority);
  t.priority = PRIORITY_CYCLE[(idx + 1) % PRIORITY_CYCLE.length];
  render();
  try {
    await Api.updateTask(id, { priority: t.priority });
  } catch (err) {
    await resyncFromServer('Could not update priority — ' + err.message);
  }
}

function toggleExpand(id){
  if(expandedIds.has(id)) expandedIds.delete(id);
  else expandedIds.add(id);
  render();
}

function collapseExpand(id){
  expandedIds.delete(id);
  render();
}

async function saveTaskEdits(id, data){
  const t = tasks.find(t => t.id === id);
  if(!t) return;
  const previous = { ...t };
  Object.assign(t, data);
  expandedIds.delete(id);
  render();
  try {
    const updated = await Api.updateTask(id, data);
    Object.assign(t, updated);
    render();
  } catch (err) {
    Object.assign(t, previous);
    render();
    showToast('Could not save changes — ' + err.message, null);
  }
}

async function removeTask(id){
  const idx = tasks.findIndex(t => t.id === id);
  if(idx === -1) return;
  const [removed] = tasks.splice(idx, 1);
  expandedIds.delete(id);
  render();
  try {
    await Api.deleteTask(id);
    showToast(`Removed "${truncate(removed.text, 30)}"`, async () => {
      try {
        await Api.restoreTask(removed);
        await resyncFromServer();
      } catch (err) {
        showToast('Could not undo — ' + err.message, null);
      }
    });
  } catch (err) {
    tasks.splice(idx, 0, removed);
    render();
    showToast('Could not remove that task — ' + err.message, null);
  }
}

async function reorderTasks(sourceId, targetId){
  if(sourceId == null || sourceId === targetId) return;
  const fromIdx = tasks.findIndex(t => t.id === sourceId);
  const toIdx = tasks.findIndex(t => t.id === targetId);
  if(fromIdx === -1 || toIdx === -1) return;
  const [moved] = tasks.splice(fromIdx, 1);
  tasks.splice(toIdx, 0, moved);
  render();
  try {
    await Api.reorderTasks(tasks.map(t => t.id));
  } catch (err) {
    await resyncFromServer('Could not save the new order — ' + err.message);
  }
}

async function clearCompleted(){
  const removedTasks = tasks.filter(t => t.done);
  if(removedTasks.length === 0) return;
  tasks = tasks.filter(t => !t.done);
  render();
  try {
    await Api.clearCompleted();
    showToast(`Cleared ${removedTasks.length} completed`, async () => {
      try {
        await Api.restoreMany(removedTasks);
        await resyncFromServer();
      } catch (err) {
        showToast('Could not undo — ' + err.message, null);
      }
    });
  } catch (err) {
    await resyncFromServer('Could not clear completed tasks — ' + err.message);
  }
}

function truncate(str, n){ return str.length > n ? str.slice(0, n-1) + '…' : str; }

/* ---------------------------------------------------------
   TOAST (with undo)
--------------------------------------------------------- */
function showToast(message, undoFn){
  const wrap = document.getElementById('toast-wrap');
  const toast = document.createElement('div');
  toast.className = 'toast';
  const msgSpan = document.createElement('span');
  msgSpan.textContent = message;
  toast.appendChild(msgSpan);
  if(undoFn){
    const undoBtn = document.createElement('button');
    undoBtn.textContent = 'Undo';
    undoBtn.addEventListener('click', () => { undoFn(); toast.remove(); });
    toast.appendChild(undoBtn);
  }
  wrap.appendChild(toast);
  setTimeout(() => { toast.remove(); }, 5000);
}

/* ---------------------------------------------------------
   EXPORT / IMPORT
--------------------------------------------------------- */
function exportTasks(){
  window.location.href = Api.exportUrl;
}

function importTasksFromFile(file){
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const parsed = JSON.parse(reader.result);
      const arr = Array.isArray(parsed) ? parsed : parsed.tasks;
      if (!Array.isArray(arr)) throw new Error('bad format');
      tasks = await Api.importTasks(arr);
      expandedIds.clear();
      render();
      showToast(`Imported ${tasks.length} tasks`, null);
    } catch (err){
      showToast('Could not read that file — expecting a Ledger export.', null);
    }
  };
  reader.readAsText(file);
}

/* ---------------------------------------------------------
   EVENTS
--------------------------------------------------------- */
document.getElementById('add-btn').addEventListener('click', addTask);
document.getElementById('task-input').addEventListener('keydown', (e) => {
  if(e.key === 'Enter') addTask();
});
document.getElementById('clear-btn').addEventListener('click', clearCompleted);

document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    render();
  });
});

document.getElementById('search-input').addEventListener('input', (e) => {
  searchQuery = e.target.value;
  render();
});

document.getElementById('tag-filter').addEventListener('change', (e) => {
  currentTagFilter = e.target.value;
  render();
});

document.getElementById('sort-select').addEventListener('change', (e) => {
  currentSort = e.target.value;
  render();
});

document.getElementById('export-btn').addEventListener('click', exportTasks);
document.getElementById('import-btn').addEventListener('click', () => document.getElementById('import-input').click());
document.getElementById('import-input').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if(file) importTasksFromFile(file);
  e.target.value = '';
});

document.addEventListener('keydown', (e) => {
  const tag = document.activeElement.tagName;
  const typing = tag === 'INPUT' || tag === 'TEXTAREA';
  if(e.key === '/' && !typing){
    e.preventDefault();
    document.getElementById('search-input').focus();
  }
});

/* ---------------------------------------------------------
   INIT
--------------------------------------------------------- */
(async function init(){
  try {
    tasks = await Api.getTasks();
  } catch (err) {
    document.getElementById('ledger').innerHTML =
      `<div class="empty-state">Could not reach the server — is it running? (${err.message})</div>`;
    return;
  }
  render();
})();
