// server/server.js
// Express app: serves the static frontend and a small REST API backed by
// server/database.js (SQLite). Run with `npm start`.

const express = require('express');
const path = require('node:path');
const ledger = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const PRIORITIES = new Set(['none', 'low', 'medium', 'high']);

function badRequest(res, message) {
  return res.status(400).json({ error: message });
}

// ---- Tasks ----------------------------------------------------------

app.get('/api/tasks', (req, res) => {
  res.json(ledger.list());
});

app.post('/api/tasks', (req, res) => {
  const text = (req.body.text || '').trim();
  if (!text) return badRequest(res, 'Task text is required.');
  if (text.length > 140) return badRequest(res, 'Task text must be 140 characters or fewer.');
  res.status(201).json(ledger.create({ text }));
});

app.patch('/api/tasks/:id', (req, res) => {
  const id = Number(req.params.id);
  const patch = {};

  if (req.body.text !== undefined) {
    const text = String(req.body.text).trim();
    if (!text) return badRequest(res, 'Task text cannot be empty.');
    patch.text = text.slice(0, 140);
  }
  if (req.body.done !== undefined) patch.done = !!req.body.done;
  if (req.body.priority !== undefined) {
    if (!PRIORITIES.has(req.body.priority)) return badRequest(res, 'Invalid priority.');
    patch.priority = req.body.priority;
  }
  if (req.body.due !== undefined) patch.due = String(req.body.due || '');
  if (req.body.tag !== undefined) patch.tag = String(req.body.tag || '').slice(0, 24);
  if (req.body.notes !== undefined) patch.notes = String(req.body.notes || '').slice(0, 2000);

  const updated = ledger.update(id, patch);
  if (!updated) return res.status(404).json({ error: 'Task not found.' });
  res.json(updated);
});

app.delete('/api/tasks/:id', (req, res) => {
  const removed = ledger.remove(Number(req.params.id));
  if (!removed) return res.status(404).json({ error: 'Task not found.' });
  res.json(removed);
});

app.post('/api/tasks/restore', (req, res) => {
  const task = req.body.task;
  if (!task || typeof task.id !== 'number') return badRequest(res, 'A full task object with id is required.');
  res.json(ledger.restore(task));
});

app.post('/api/tasks/reorder', (req, res) => {
  const { orderedIds } = req.body;
  if (!Array.isArray(orderedIds)) return badRequest(res, 'orderedIds must be an array.');
  res.json(ledger.reorder(orderedIds));
});

app.post('/api/tasks/clear-completed', (req, res) => {
  res.json(ledger.clearCompleted());
});

app.post('/api/tasks/restore-many', (req, res) => {
  const arr = req.body.tasks;
  if (!Array.isArray(arr)) return badRequest(res, 'tasks must be an array.');
  res.json(ledger.restoreMany(arr));
});

// ---- Backup / restore whole list ------------------------------------

app.get('/api/export', (req, res) => {
  const payload = { exportedAt: new Date().toISOString(), tasks: ledger.list() };
  res.setHeader('Content-Disposition', 'attachment; filename="ledger-tasks.json"');
  res.json(payload);
});

app.post('/api/import', (req, res) => {
  const arr = req.body.tasks;
  if (!Array.isArray(arr)) return badRequest(res, 'Expected a "tasks" array.');
  res.json(ledger.replaceAll(arr));
});

// ---- Fallbacks --------------------------------------------------------

// Any unmatched /api/* route -> clean JSON 404 instead of Express's default HTML page.
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'No such API route.' });
});

// Malformed JSON bodies, and any other error thrown in a handler above,
// land here as JSON instead of an HTML stack-trace page.
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed' || err instanceof SyntaxError) {
    return res.status(400).json({ error: 'Malformed JSON in request body.' });
  }
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

const server = app.listen(PORT, () => {
  console.log(`The Ledger is running at http://localhost:${PORT}`);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Set PORT=<number> to use a different one, e.g.:`);
    console.error(`  PORT=3001 npm start`);
    process.exit(1);
  }
  throw err;
});
