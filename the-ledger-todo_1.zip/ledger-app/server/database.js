// server/database.js
// Persistence layer. Uses Node's built-in SQLite (node:sqlite, stable since
// Node 22.5+) so the project needs no native build tools or extra services.

const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'ledger.db');
const db = new DatabaseSync(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS tasks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    text       TEXT    NOT NULL,
    done       INTEGER NOT NULL DEFAULT 0,
    priority   TEXT    NOT NULL DEFAULT 'none',
    due        TEXT    DEFAULT '',
    tag        TEXT    DEFAULT '',
    notes      TEXT    DEFAULT '',
    position   INTEGER NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  );
`);

function rowToTask(row) {
  return {
    id: row.id,
    text: row.text,
    done: !!row.done,
    priority: row.priority,
    due: row.due || '',
    tag: row.tag || '',
    notes: row.notes || '',
    position: row.position,
    createdAt: row.created_at
  };
}

const statements = {
  all: db.prepare('SELECT * FROM tasks ORDER BY position ASC, id ASC'),
  maxPosition: db.prepare('SELECT COALESCE(MAX(position), -1) AS maxPos FROM tasks'),
  insert: db.prepare(`
    INSERT INTO tasks (text, done, priority, due, tag, notes, position)
    VALUES (@text, @done, @priority, @due, @tag, @notes, @position)
  `),
  insertWithId: db.prepare(`
    INSERT OR IGNORE INTO tasks (id, text, done, priority, due, tag, notes, position, created_at)
    VALUES (@id, @text, @done, @priority, @due, @tag, @notes, @position, @createdAt)
  `),
  getById: db.prepare('SELECT * FROM tasks WHERE id = ?'),
  deleteById: db.prepare('DELETE FROM tasks WHERE id = ?'),
  deleteDone: db.prepare('DELETE FROM tasks WHERE done = 1'),
  deleteAll: db.prepare('DELETE FROM tasks'),
  updatePosition: db.prepare('UPDATE tasks SET position = ? WHERE id = ?')
};

const ledger = {
  list() {
    return statements.all.all().map(rowToTask);
  },

  create({ text }) {
    const nextPos = statements.maxPosition.get().maxPos + 1;
    const info = statements.insert.run({
      text,
      done: 0,
      priority: 'none',
      due: '',
      tag: '',
      notes: '',
      position: nextPos
    });
    return rowToTask(statements.getById.get(info.lastInsertRowid));
  },

  update(id, patch) {
    const existing = statements.getById.get(id);
    if (!existing) return null;

    const next = {
      text: patch.text !== undefined ? patch.text : existing.text,
      done: patch.done !== undefined ? (patch.done ? 1 : 0) : existing.done,
      priority: patch.priority !== undefined ? patch.priority : existing.priority,
      due: patch.due !== undefined ? patch.due : existing.due,
      tag: patch.tag !== undefined ? patch.tag : existing.tag,
      notes: patch.notes !== undefined ? patch.notes : existing.notes
    };

    db.prepare(`
      UPDATE tasks SET text=@text, done=@done, priority=@priority, due=@due, tag=@tag, notes=@notes
      WHERE id=@id
    `).run({ ...next, id });

    return rowToTask(statements.getById.get(id));
  },

  remove(id) {
    const existing = statements.getById.get(id);
    if (!existing) return null;
    statements.deleteById.run(id);
    return rowToTask(existing);
  },

  restore(task) {
    statements.insertWithId.run({
      id: task.id,
      text: task.text,
      done: task.done ? 1 : 0,
      priority: task.priority || 'none',
      due: task.due || '',
      tag: task.tag || '',
      notes: task.notes || '',
      position: task.position ?? statements.maxPosition.get().maxPos + 1,
      createdAt: task.createdAt || new Date().toISOString()
    });
    return this.list();
  },

  reorder(orderedIds) {
    const tx = db.prepare('BEGIN');
    tx.run();
    try {
      orderedIds.forEach((id, index) => statements.updatePosition.run(index, id));
      db.prepare('COMMIT').run();
    } catch (err) {
      db.prepare('ROLLBACK').run();
      throw err;
    }
    return this.list();
  },

  clearCompleted() {
    const removed = db.prepare('SELECT * FROM tasks WHERE done = 1').all().map(rowToTask);
    statements.deleteDone.run();
    return removed;
  },

  restoreMany(tasksArr) {
    tasksArr.forEach(t => this.restore(t));
    return this.list();
  },

  replaceAll(tasksArr) {
    const tx = db.prepare('BEGIN');
    tx.run();
    try {
      statements.deleteAll.run();
      tasksArr.forEach((t, index) => {
        statements.insert.run({
          text: t.text || 'Untitled task',
          done: t.done ? 1 : 0,
          priority: t.priority || 'none',
          due: t.due || '',
          tag: t.tag || '',
          notes: t.notes || '',
          position: index
        });
      });
      db.prepare('COMMIT').run();
    } catch (err) {
      db.prepare('ROLLBACK').run();
      throw err;
    }
    return this.list();
  }
};

module.exports = ledger;
