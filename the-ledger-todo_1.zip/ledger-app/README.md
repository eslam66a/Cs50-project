# The Ledger — a full-stack to-do list

A small, complete to-do app split across the languages that actually do the work:

- **HTML** (`public/index.html`) — page structure
- **CSS** (`public/css/style.css`) — the ledger/paper design, light + dark
- **JavaScript, client-side** (`public/js/api.js`, `public/js/app.js`) — UI behavior and talking to the server
- **JavaScript, server-side** (`server/server.js`) — an Express app and REST API
- **SQL** (`server/database.js`) — schema and queries against a real SQLite database, using Node's built-in `node:sqlite`

Your list is stored in an actual database file (`data/ledger.db`), so it survives restarts, refreshes, and closing the browser — no more losing your tasks on reload.

## Requirements

- Node.js **22.5 or newer** (for built-in SQLite support). Check with `node -v`.

## Running it

```bash
npm install
npm start
```

Then open **http://localhost:3000** in your browser.

For development with auto-restart on file changes:

```bash
npm run dev
```

## What it does

- Add, check off, edit, and delete tasks
- Set a due date, a tag, a priority (low/medium/high), and notes on any task
- Search, filter by tag, filter by All/Active/Done, and sort (manual/priority/due date/alphabetical)
- Drag to reorder (while sort is set to Manual)
- Undo on delete and on "clear completed"
- Light/dark theme toggle (remembered between visits)
- Export your list to a `.json` file, or import one back in

## Project layout

```
the-ledger-todo/
├── package.json
├── README.md
├── data/
│   └── ledger.db          (created automatically on first run)
├── server/
│   ├── server.js          Express app + REST API
│   └── database.js        SQLite schema and queries
└── public/
    ├── index.html
    ├── css/
    │   └── style.css
    └── js/
        ├── api.js          fetch() wrapper for the API
        └── app.js          rendering and interaction logic
```

## API reference

| Method | Path                          | Purpose                                 |
|--------|-------------------------------|------------------------------------------|
| GET    | `/api/tasks`                  | List all tasks                          |
| POST   | `/api/tasks`                  | Create a task — body `{ text }`         |
| PATCH  | `/api/tasks/:id`               | Update a task (any subset of fields)    |
| DELETE | `/api/tasks/:id`               | Delete a task                           |
| POST   | `/api/tasks/restore`           | Re-insert a previously deleted task     |
| POST   | `/api/tasks/reorder`           | Body `{ orderedIds: [...] }`            |
| POST   | `/api/tasks/clear-completed`   | Delete all completed tasks              |
| POST   | `/api/tasks/restore-many`      | Body `{ tasks: [...] }`                 |
| GET    | `/api/export`                  | Download the full list as JSON          |
| POST   | `/api/import`                  | Replace the list — body `{ tasks: [...] }` |

## Notes

- The SQLite integration uses `node:sqlite`, which is still marked experimental by Node — you'll see a one-line warning in the terminal on startup. It's safe to ignore.
- If your Node version is 22.5–22.x and `node:sqlite` isn't available by default, run the server with `node --experimental-sqlite server/server.js` instead.
